for i in range(0, 10):
    soma = int(input())
    diff = int(input())

    print((soma + diff) // 2)
    print((soma - ((soma + diff) // 2)))
