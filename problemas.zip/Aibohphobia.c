#include <stdio.h>

int main() {

  //Read the number of strings
  int n;
  scanf("%d\n", &n);

  //Read strings

  return 0;
}
